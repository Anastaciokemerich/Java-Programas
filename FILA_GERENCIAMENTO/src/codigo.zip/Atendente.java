/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filacomprioridade1atendenteb;

import java.util.LinkedList;

/**
 *
 * @author mirkos@unifra.br
 */
public class Atendente {
    
    public LinkedList<Cliente> clientesAtendidos = 
            new LinkedList<Cliente>();
    
    public void mostraClientesAtendidos(){
        for(int x=0;x<clientesAtendidos.size();x++){
            Cliente atendido = clientesAtendidos.get(x);
            System.out.println("Cliente ID:"+atendido.getID()+
                    " prioridade: "+atendido.getPrioridade()+
                    " num itens: "+atendido.getItens());
        }
    }
    
    /**
     * Atende o cliente, calcula tpa e tta e adiciona
     * na lista clientesAtendidos
     * @param cliente 
     */
    public void atende(Cliente cliente){
        this.tpa = (float)cliente.getItens()/this.velAtend;
        this.tta = this.tta + this.tpa;
        //this.tta += this.tpa;
        System.out.println("TPA: "+this.tpa+" - TTA: "+this.tta);       
        this.clientesAtendidos.add(cliente);
        this.mostraClientesAtendidos();
    }

    //tta=tempo total de atendimento;tpa=tempo parcial de atendimento
    public float tta;
    public float tpa;
    /**
     * @return the velAtend
     */
    public int getVelAtend() {
        return velAtend;
    }

    /**
     * @param velAtend the velAtend to set
     */
    public void setVelAtend(int velAtend) {
        this.velAtend = velAtend;
    }
    
    //Velocidade de atendimento
    private int velAtend;
}
