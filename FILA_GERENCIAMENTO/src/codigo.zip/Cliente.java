/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filacomprioridade1atendenteb;

/**
 *
 * @author usrlab01
 */
public class Cliente {

    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * @return the prioridade
     */
    public int getPrioridade() {
        return prioridade;
    }

    /**
     * @param prioridade the prioridade to set
     */
    public void setPrioridade(int prioridade) {
        this.prioridade = prioridade;
    }

    /**
     * @return the itens
     */
    public int getItens() {
        return itens;
    }

    /**
     * @param itens the itens to set
     */
    public void setItens(int itens) {
        this.itens = itens;
    }
    private int ID;
    private int prioridade;
    private int itens;
    private int tempoNaFila=0;
    
    public void aumentaPrioridade(){
        if(this.prioridade!=3){
            this.prioridade++;
        }
    }
    
    public void atualizaTempo(){
        this.tempoNaFila++;
        if(this.tempoNaFila>=10){
            this.aumentaPrioridade();
            this.tempoNaFila = 0;
        }
    }
    

}
