/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filacomprioridade1atendenteb;

import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

/**
 * @version 1.0
 * @author mirkos@unifra.br
 */
public class FilaComPrioridade1AtendenteB {
    
    LinkedList<Cliente> fila = new LinkedList<Cliente>();
    public int IDGlobal=20;
    /**
     *
     * INICIALIZA A FILA COM PELO MENOS 20 CLIENTES, COM PRIORIDADE E NRO. ITENS ALEATÓRIOS
     * 
     */
    public void inicializaFila(){
        Random random = new Random();//para a prioridade
        Random rand2 = new Random();//para o número de itens
        for(int x=0;x<20;x++){
            Cliente cli = new Cliente();
            cli.setID(x+1);
            
            cli.setPrioridade(random.nextInt(3)+1);
            
            cli.setItens(rand2.nextInt(50)+1);
            System.out.println("Cliente["+cli.getID()+"]: prioridade: "+cli.getPrioridade()+" - itens: "+cli.getItens());
            //adiciona o cliente na fila
            fila.add(cli);
        }
        
    }
    
    public void atualizaTClientes(){
        for(int x=0;x<this.fila.size();x++){
            Cliente cli = this.fila.get(x);
            cli.atualizaTempo();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FilaComPrioridade1AtendenteB fcp = new FilaComPrioridade1AtendenteB();
        fcp.inicializaFila();
        System.out.println("Digite a velocidade do atendente: ");
        Scanner teclado = new Scanner(System.in);
        //Instancia o atendente
        Atendente atendente = new Atendente();
        atendente.setVelAtend(teclado.nextInt());
        int index =0;
        
        //FILA EM ATENDIMENTO
        while(!fcp.fila.isEmpty()){
            //Manda o cliente com maior prioridade para o atendente
            Cliente proximo = fcp.proximoClienteMaiorPrior();
            atendente.atende(proximo);
            System.out.println("ID cli remover: "+proximo.getID());
            fcp.fila.remove(proximo);
            //Atualiza o tempo dos clientes
            fcp.atualizaTClientes();
            if(index%2==0 && index!=0){
                Cliente novo = new Cliente();
                Random rd = new Random();
                fcp.IDGlobal++;
                novo.setID(fcp.IDGlobal);
                novo.setPrioridade(rd.nextInt(3)+1);
                novo.setItens(rd.nextInt(50)+1);
                fcp.fila.add(novo);
            }
            index++;
            System.out.println("Index: "+index);
        }
    }

    private Cliente proximoClienteMaiorPrior() {
        for(int x=0;x<this.fila.size();x++){
            Cliente cli = this.fila.get(x);
            if(cli.getPrioridade()==3)
            {this.fila.remove(x);
            return cli;
            }
            }
        for(int y=0;y<this.fila.size();y++){
            Cliente cli = this.fila.get(y);
            if(cli.getPrioridade()==2)
            {this.fila.remove(y);return cli;}
            }
        for(int z=0;z<this.fila.size();z++){
            Cliente cli = this.fila.get(z);
            if(cli.getPrioridade()==1)
            {this.fila.remove(z);return cli;}
            }
        return null;       
    }
    
}
