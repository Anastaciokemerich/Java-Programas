package montadoraulaprogsistemas;

public class Saida {

	String comando;
	
	public String getComando() {
		return comando;
	}
	public void setComando(String comando) {
		this.comando = comando;
	}
	public String getPrimeiroP() {
		return primeiroP;
	}
	public void setPrimeiroP(String primeiroP) {
		this.primeiroP = primeiroP;
	}
	public String getSegundoP() {
		return segundoP;
	}
	public void setSegundoP(String segundoP) {
		this.segundoP = segundoP;
	}
	String primeiroP;
	String segundoP;
	
	
}
